﻿using System;
using System.IO;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {

        try
        {
            string inputFilePath = @"..\..\..\F1.txt";
            string text = File.ReadAllText(inputFilePath);


            string pattern = "\\((.*?)\\)";
            Match match = Regex.Match(text, pattern);

            if (match.Success)
            {
                string quotedText = match.Groups[1].Value;
                Console.WriteLine("Слова в перших дужках: " + quotedText);
            }
            else
            {
                Console.WriteLine("Дужок не знайдено.");
            }
            string modifiedText = text.Replace(" ", " ! ");

            string outputFilePath = @"..\..\..\F2.txt";
            File.WriteAllText(outputFilePath, modifiedText);

            Console.WriteLine("Текст успішно змінено та збережено у F2.txt");
        }
        catch (Exception e)
        {
            Console.WriteLine("Сталася помилка: " + e.Message);
        }
    }
}
