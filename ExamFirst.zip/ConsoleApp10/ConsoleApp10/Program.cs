﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace BookManager
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.OutputEncoding = Encoding.UTF8;

            string filePath = @"..\..\..\books.xml";
            XDocument doc = XDocument.Load(filePath);

            while (true)
            {
                Console.WriteLine("1. Вивести книги з більше ніж 150 сторінками");
                Console.WriteLine("2. Додати книгу");
                Console.WriteLine("3. Видалити книгу");
                Console.WriteLine("4. Редагувати книгу");
                Console.WriteLine("5. Вийти");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        DisplayBooks(doc);
                        Console.WriteLine("");
                        break;
                    case "2":
                        AddBook(doc, filePath);
                        Console.WriteLine("");
                        break;
                    case "3":
                        DeleteBook(doc, filePath);
                        Console.WriteLine("");
                        break;
                    case "4":
                        EditBook(doc, filePath);
                        Console.WriteLine("");
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                        Console.WriteLine("");
                        break;
                }
            }
        }

        static void DisplayBooks(XDocument doc)
        {
            var books = doc.Descendants("book")
                           .Where(x => (int)x.Element("pages") > 150)
                           .Select(x => new
                           {
                               Title = x.Element("title").Value,
                               Author = x.Element("author").Value,
                               Pages = x.Element("pages").Value,
                               Copies = x.Element("copies").Value,
                               Year = x.Element("year").Value
                           });

            foreach (var book in books)
            {
                Console.WriteLine($"Назва: {book.Title}, Автор: {book.Author}, Сторінок: {book.Pages}, Копій: {book.Copies}, Рік: {book.Year}");
            }
        }

        static void AddBook(XDocument doc, string filePath)
        {
            Console.Write("Назва: ");
            string title = Console.ReadLine();
            Console.Write("Автор: ");
            string author = Console.ReadLine();
            Console.Write("Сторінок: ");
            int pages = int.Parse(Console.ReadLine());
            Console.Write("Копій: ");
            int copies = int.Parse(Console.ReadLine());
            Console.Write("Рік: ");
            int year = int.Parse(Console.ReadLine());

            XElement newBook = new XElement("book",
                new XElement("title", title),
                new XElement("author", author),
                new XElement("pages", pages),
                new XElement("copies", copies),
                new XElement("year", year));

            doc.Root.Add(newBook);
            doc.Save(filePath);
            Console.WriteLine("Книгу додано.");
        }

        static void DeleteBook(XDocument doc, string filePath)
        {
            Console.Write("Введіть назву книги для видалення: ");
            string title = Console.ReadLine();

            var book = doc.Descendants("book")
                          .FirstOrDefault(x => x.Element("title").Value == title);

            if (book != null)
            {
                book.Remove();
                doc.Save(filePath);
                Console.WriteLine("Книгу видалено.");
            }
            else
            {
                Console.WriteLine("Книга не знайдена.");
            }
        }

        static void EditBook(XDocument doc, string filePath)
        {
            Console.Write("Введіть назву книги для редагування: ");
            string title = Console.ReadLine();

            var book = doc.Descendants("book")
                          .FirstOrDefault(x => x.Element("title").Value == title);

            if (book != null)
            {
                Console.Write("Нова назва (залиште порожнім, щоб не змінювати): ");
                string newTitle = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(newTitle))
                {
                    book.Element("title").Value = newTitle;
                }

                Console.Write("Новий автор (залиште порожнім, щоб не змінювати): ");
                string newAuthor = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(newAuthor))
                {
                    book.Element("author").Value = newAuthor;
                }

                Console.Write("Нові сторінки (залиште порожнім, щоб не змінювати): ");
                string newPages = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(newPages))
                {
                    book.Element("pages").Value = newPages;
                }

                Console.Write("Нові копії (залиште порожнім, щоб не змінювати): ");
                string newCopies = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(newCopies))
                {
                    book.Element("copies").Value = newCopies;
                }

                Console.Write("Новий рік (залиште порожнім, щоб не змінювати): ");
                string newYear = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(newYear))
                {
                    book.Element("year").Value = newYear;
                }

                doc.Save(filePath);
                Console.WriteLine("Книгу відредаговано.");
            }
            else
            {
                Console.WriteLine("Книга не знайдена.");
            }
        }
    }
}
